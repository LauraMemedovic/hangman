# Evidencija aktivnosti
## 04.06.2023.
Pocetak | Kraj
------- | ----
18:00   | 20:00
### Kratki opis promjena
Okvirna struktura aplikacije.
Dodane neke od komponenti i ekrani koje će igra sadržavati (početni ekran, ekran za igru).

## 10.06.2023.
Pocetak | Kraj
------- | ----
12:00   | 20:00
### Kratki opis promjena
Izmjena strukture aplikacije.
Promjena ekrana koje će aplikacija sadržavati.
Upravljanje akcijama pri pogađanju broja.

## 11.06.2023.
Pocetak | Kraj
------- | ----
15:00   | 23:00
### Kratki opis promjena
Rad na akcijama koje se pozivaju pri pogađanju broja.
Izmjene na ekranu za igru.
Dodavanje slike i uređivanje izgleda.

## 12.06.2023.
Pocetak | Kraj
------- | ----
10:00   | 12:00
### Kratki opis promjena
Dodatne provjere funkcionalnosti aplikacije.
Upload na GitHub.

## 13.06.2023.
Pocetak | Kraj
------- | ----
18:00   | 21:00
### Kratki opis promjena
Dodan ekran za kraj igre.
Dodatne provjere funkcionalnosti aplikacije.
Upload na GitHub.

## 19.06.2023.
Pocetak | Kraj
------- | ----
19:00   | 01:00
### Kratki opis promjena
Dodavanje mogućnosti odabira težine igre (lagano/srednje/teško) i kategorije (filmovi/serije) na početni ekran.



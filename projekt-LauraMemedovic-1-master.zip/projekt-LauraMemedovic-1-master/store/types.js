export const START_GAME = 'START_GAME';
export const POGODI_SLOVO = 'POGODI_SLOVO';
